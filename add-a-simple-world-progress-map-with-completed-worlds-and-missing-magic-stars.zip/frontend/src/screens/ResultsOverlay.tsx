import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Trophy } from 'lucide-react';

interface ResultsOverlayProps {
  levelName: string;
  starsEarned: number;
  timeTaken: number;
  badges: string[];
  onContinue: () => void;
}

export default function ResultsOverlay({ levelName, starsEarned, timeTaken, badges, onContinue }: ResultsOverlayProps) {
  const minutes = Math.floor(timeTaken / 60);
  const seconds = timeTaken % 60;

  return (
    <Dialog open={true} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-3xl text-center font-bold text-primary">
            🎉 Level Complete! 🎉
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Level Name */}
          <p className="text-xl text-center font-semibold">{levelName}</p>

          {/* Stars */}
          <div className="flex justify-center gap-2 animate-celebration">
            {[1, 2, 3].map((starNum) => (
              <Star
                key={starNum}
                className={`h-12 w-12 ${starNum <= starsEarned ? 'text-star fill-star animate-pulse-glow' : 'text-muted-foreground'}`}
                style={{ animationDelay: `${starNum * 0.2}s` }}
              />
            ))}
          </div>

          {/* Time */}
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Time</p>
            <p className="text-2xl font-bold">
              {minutes > 0 && `${minutes}m `}{seconds}s
            </p>
          </div>

          {/* Badges */}
          {badges.length > 0 && (
            <div className="space-y-2">
              <p className="text-center font-semibold flex items-center justify-center gap-2">
                <Trophy className="h-5 w-5 text-warning" />
                New Badges!
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                {badges.map((badge, index) => (
                  <Badge 
                    key={index} 
                    className="bg-warning text-white animate-celebration"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    {badge}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Encouraging Message */}
          <p className="text-center text-lg text-muted-foreground">
            {starsEarned === 3 ? "Perfect! You're amazing! ⭐" : 
             starsEarned === 2 ? "Great job! Keep it up! 🌟" : 
             "Good work! Try again for more stars! ✨"}
          </p>
        </div>

        <DialogFooter>
          <Button onClick={onContinue} size="lg" className="w-full game-button bg-primary hover:bg-primary/90">
            Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
