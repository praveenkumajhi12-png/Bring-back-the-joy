import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { worlds } from '../game/content/worlds';
import { worldDialogs } from '../game/content/dialogs';

interface WorldIntroDialogProps {
  worldId: string;
  onComplete: () => void;
}

export default function WorldIntroDialog({ worldId, onComplete }: WorldIntroDialogProps) {
  const world = worlds.find(w => w.id === worldId);
  const dialog = worldDialogs[worldId];

  if (!world || !dialog) {
    onComplete();
    return null;
  }

  return (
    <Dialog open={true} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-3xl text-center font-bold" style={{ color: `oklch(var(--${world.theme}))` }}>
            {world.icon} {world.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* NPC */}
          <div className="text-center">
            <div className="text-7xl mb-4 animate-bounce-gentle">{dialog.npcIcon}</div>
            <p className="text-lg font-semibold">{dialog.npcName}</p>
          </div>

          {/* Dialog */}
          <div className="bg-muted/50 rounded-lg p-6 space-y-3">
            <p className="text-lg">{dialog.greeting}</p>
            <p className="text-lg">{dialog.problem}</p>
            <p className="text-lg font-semibold text-primary">{dialog.request}</p>
          </div>

          {/* Positive Value */}
          <div className="bg-success/10 rounded-lg p-4 text-center">
            <p className="text-sm font-semibold text-success">💚 {dialog.positiveValue}</p>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onComplete} size="lg" className="w-full game-button bg-primary hover:bg-primary/90">
            Let's Help! 🌟
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
