import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Star } from 'lucide-react';
import { worlds } from '../game/content/worlds';
import type { LocalProgress } from '../progress/localProgressStore';

interface ProgressMapScreenProps {
  progress: LocalProgress | null;
  onBack: () => void;
}

export default function ProgressMapScreen({ progress, onBack }: ProgressMapScreenProps) {
  const getWorldStats = (worldId: string) => {
    const world = worlds.find(w => w.id === worldId);
    if (!world) return { completed: false, earnedStars: 0, maxStars: 0, missingStars: 0 };

    const maxStars = world.levels.length * 3;
    
    if (!progress) {
      return { completed: false, earnedStars: 0, maxStars, missingStars: maxStars };
    }

    const completedLevelsInWorld = world.levels.filter(level =>
      progress.completedLevels.some(cl => cl.levelId === level.id)
    );

    const completed = completedLevelsInWorld.length === world.levels.length;

    const earnedStars = world.levels.reduce((sum, level) => {
      const completedLevel = progress.completedLevels.find(cl => cl.levelId === level.id);
      return sum + (completedLevel?.starsEarned || 0);
    }, 0);

    const missingStars = Math.max(0, maxStars - earnedStars);

    return { completed, earnedStars, maxStars, missingStars };
  };

  const totalEarnedStars = progress?.completedLevels.reduce((sum, level) => sum + level.starsEarned, 0) || 0;
  const totalMaxStars = worlds.reduce((sum, world) => sum + world.levels.length * 3, 0);
  const totalMissingStars = Math.max(0, totalMaxStars - totalEarnedStars);

  return (
    <div
      className="min-h-screen p-4 md:p-8 relative overflow-hidden"
      style={{
        backgroundImage: 'url(/assets/generated/bg-forest.dim_1920x1080.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-background/70" />

      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            size="lg"
            className="bg-card/90"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back
          </Button>

          <div className="flex items-center gap-2">
            <img
              src="/assets/generated/magic-stars.dim_512x512.png"
              alt="Magic Stars"
              className="w-8 h-8 md:w-10 md:h-10"
            />
            <Badge variant="secondary" className="text-base md:text-lg px-3 md:px-4 py-2">
              <Star className="mr-2 h-4 w-4 md:h-5 md:w-5 text-star" />
              {totalEarnedStars} / {totalMaxStars}
            </Badge>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8 md:mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-3 md:mb-4">
            Progress Map
          </h1>
          <p className="text-lg md:text-xl text-foreground">
            Track your journey through all the magical worlds!
          </p>
        </div>

        {/* Overall Progress */}
        <Card className="mb-6 md:mb-8 bg-card/90 backdrop-blur-sm border-2 border-primary">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center justify-between flex-wrap gap-2">
              <span>Overall Progress</span>
              <Badge variant="outline" className="text-base md:text-lg">
                {totalMissingStars} stars to collect
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm md:text-base">
                <span>Total Stars Collected</span>
                <span className="font-semibold">{totalEarnedStars} / {totalMaxStars}</span>
              </div>
              <Progress value={(totalEarnedStars / totalMaxStars) * 100} className="h-3 md:h-4" />
            </div>
          </CardContent>
        </Card>

        {/* World Progress Cards */}
        <div className="space-y-4 md:space-y-6">
          {worlds.map((world) => {
            const stats = getWorldStats(world.id);
            const progressPercent = stats.maxStars > 0 ? (stats.earnedStars / stats.maxStars) * 100 : 0;

            return (
              <Card
                key={world.id}
                className="bg-card/90 backdrop-blur-sm border-4 transition-all hover:scale-[1.02]"
                style={{ borderColor: `oklch(var(--${world.theme}))` }}
              >
                <CardHeader>
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <CardTitle
                      className="text-2xl md:text-3xl font-bold flex items-center gap-2"
                      style={{ color: `oklch(var(--${world.theme}))` }}
                    >
                      <span className="text-3xl md:text-4xl">{world.icon}</span>
                      <span>{world.name}</span>
                    </CardTitle>
                    {stats.completed && (
                      <Badge className="bg-success text-white text-sm md:text-base">
                        ✓ Complete!
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
                    <div className="flex items-center gap-2 bg-muted/50 p-3 rounded-lg">
                      <Star className="h-5 w-5 md:h-6 md:w-6 text-star flex-shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs md:text-sm text-muted-foreground">Earned</div>
                        <div className="text-lg md:text-xl font-bold truncate">{stats.earnedStars}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 bg-muted/50 p-3 rounded-lg">
                      <img
                        src="/assets/generated/magic-stars.dim_512x512.png"
                        alt="Missing Stars"
                        className="w-5 h-5 md:w-6 md:h-6 opacity-50 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-xs md:text-sm text-muted-foreground">Missing</div>
                        <div className="text-lg md:text-xl font-bold truncate">{stats.missingStars}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 bg-muted/50 p-3 rounded-lg">
                      <span className="text-xl md:text-2xl flex-shrink-0">🎯</span>
                      <div className="min-w-0">
                        <div className="text-xs md:text-sm text-muted-foreground">Max Stars</div>
                        <div className="text-lg md:text-xl font-bold truncate">{stats.maxStars}</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm md:text-base">
                      <span>Progress</span>
                      <span className="font-semibold">
                        {stats.earnedStars} / {stats.maxStars} stars
                      </span>
                    </div>
                    <Progress value={progressPercent} className="h-3 md:h-4" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
