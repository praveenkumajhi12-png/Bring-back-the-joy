import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Star, Lock } from 'lucide-react';
import { worlds } from '../game/content/worlds';
import type { LocalProgress } from '../progress/localProgressStore';

interface LevelSelectScreenProps {
  worldId: string;
  onSelectLevel: (levelId: string) => void;
  onBack: () => void;
  progress: LocalProgress | null;
}

export default function LevelSelectScreen({ worldId, onSelectLevel, onBack, progress }: LevelSelectScreenProps) {
  const world = worlds.find(w => w.id === worldId);
  
  if (!world) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>World not found</p>
      </div>
    );
  }

  const getLevelStatus = (levelId: string, index: number) => {
    if (!progress) return { completed: false, stars: 0, locked: index > 0 };
    
    const completedLevel = progress.completedLevels.find(cl => cl.levelId === levelId);
    const isCompleted = !!completedLevel;
    
    // First level is always unlocked, others unlock after previous level is completed
    const isLocked = index > 0 && !progress.completedLevels.some(cl => cl.levelId === world.levels[index - 1].id);
    
    return {
      completed: isCompleted,
      stars: completedLevel?.starsEarned || 0,
      locked: isLocked
    };
  };

  return (
    <div 
      className="min-h-screen p-8 relative overflow-hidden"
      style={{
        backgroundImage: `url(/assets/generated/bg-${world.backgroundImage}.dim_1920x1080.png)`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-background/60" />
      
      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            size="lg"
            className="bg-card/80"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Worlds
          </Button>
        </div>

        {/* World Title */}
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 animate-bounce-gentle" style={{ color: `oklch(var(--${world.theme}))` }}>
            {world.icon} {world.name}
          </h1>
          <p className="text-xl text-foreground">{world.description}</p>
        </div>

        {/* Level Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {world.levels.map((level, index) => {
            const status = getLevelStatus(level.id, index);

            return (
              <Card
                key={level.id}
                className={`level-card ${status.locked ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:shadow-xl'} bg-card/90 backdrop-blur-sm border-2`}
                style={{ borderColor: status.completed ? `oklch(var(--success))` : `oklch(var(--${world.theme}))` }}
                onClick={() => !status.locked && onSelectLevel(level.id)}
              >
                <CardContent className="p-6 space-y-4">
                  {/* Level Number */}
                  <div className="flex items-center justify-between">
                    <Badge 
                      variant={status.completed ? "default" : "outline"}
                      className="text-lg px-3 py-1"
                      style={status.completed ? { backgroundColor: `oklch(var(--success))` } : {}}
                    >
                      Level {level.levelNumber}
                    </Badge>
                    {status.locked && <Lock className="h-5 w-5 text-muted-foreground" />}
                  </div>

                  {/* Level Icon */}
                  <div className="text-6xl text-center animate-float">
                    {level.icon}
                  </div>

                  {/* Level Name */}
                  <h3 className="text-xl font-bold text-center">{level.name}</h3>

                  {/* Level Type */}
                  <p className="text-sm text-muted-foreground text-center">{level.type}</p>

                  {/* Stars */}
                  <div className="flex justify-center gap-1">
                    {[1, 2, 3].map((starNum) => (
                      <Star
                        key={starNum}
                        className={`h-6 w-6 ${starNum <= status.stars ? 'text-star fill-star' : 'text-muted-foreground'}`}
                      />
                    ))}
                  </div>

                  {/* Status Badge */}
                  {status.completed && (
                    <Badge className="w-full justify-center bg-success text-white">
                      ✓ Completed
                    </Badge>
                  )}
                  {status.locked && (
                    <Badge variant="outline" className="w-full justify-center">
                      Complete previous level
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
