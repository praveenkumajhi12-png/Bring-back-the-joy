import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Star, Trophy } from 'lucide-react';
import { worlds } from '../game/content/worlds';
import { allBadges } from '../game/rewards/badges';
import type { LocalProgress } from '../progress/localProgressStore';

interface CollectionScreenProps {
  onClose: () => void;
  progress: LocalProgress | null;
}

export default function CollectionScreen({ onClose, progress }: CollectionScreenProps) {
  const totalStars = progress?.completedLevels.reduce((sum, level) => sum + level.starsEarned, 0) || 0;
  const totalLevels = worlds.reduce((sum, world) => sum + world.levels.length, 0);
  const completedLevels = progress?.completedLevels.length || 0;
  const earnedBadges = progress?.badges || [];

  const getWorldStats = (worldId: string) => {
    const world = worlds.find(w => w.id === worldId);
    if (!world || !progress) return { stars: 0, completed: 0, total: 0 };

    const worldLevelIds = world.levels.map(l => l.id);
    const worldCompletedLevels = progress.completedLevels.filter(cl => worldLevelIds.includes(cl.levelId));
    
    const stars = worldCompletedLevels.reduce((sum, level) => sum + level.starsEarned, 0);
    const completed = worldCompletedLevels.length;
    
    return { stars, completed, total: world.levels.length };
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/10 to-background p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button onClick={onClose} variant="outline" size="lg">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back
          </Button>
          <h1 className="text-4xl md:text-5xl font-bold text-primary">
            <Trophy className="inline-block mr-2 h-10 w-10" />
            My Collection
          </h1>
          <div className="w-24" /> {/* Spacer for centering */}
        </div>

        {/* Overall Stats */}
        <Card className="mb-8 bg-card/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Overall Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <Star className="h-8 w-8 text-star mx-auto mb-2" />
                <p className="text-3xl font-bold">{totalStars}</p>
                <p className="text-sm text-muted-foreground">Total Stars</p>
              </div>
              <div className="text-center p-4 bg-success/10 rounded-lg">
                <Trophy className="h-8 w-8 text-success mx-auto mb-2" />
                <p className="text-3xl font-bold">{completedLevels}</p>
                <p className="text-sm text-muted-foreground">Levels Complete</p>
              </div>
              <div className="text-center p-4 bg-warning/10 rounded-lg">
                <Badge className="h-8 w-8 bg-warning mx-auto mb-2 flex items-center justify-center">
                  {earnedBadges.length}
                </Badge>
                <p className="text-3xl font-bold">{earnedBadges.length}</p>
                <p className="text-sm text-muted-foreground">Badges Earned</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Progress</span>
                <span className="font-semibold">{completedLevels} / {totalLevels} levels</span>
              </div>
              <Progress value={(completedLevels / totalLevels) * 100} className="h-3" />
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="worlds" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="worlds">Worlds</TabsTrigger>
            <TabsTrigger value="badges">Badges</TabsTrigger>
          </TabsList>

          {/* Worlds Tab */}
          <TabsContent value="worlds" className="space-y-4">
            {worlds.map((world) => {
              const stats = getWorldStats(world.id);
              const progressPercent = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0;

              return (
                <Card key={world.id} className="bg-card/90 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span style={{ color: `oklch(var(--${world.theme}))` }}>
                        {world.icon} {world.name}
                      </span>
                      <Badge variant="outline">
                        <Star className="mr-1 h-4 w-4 text-star" />
                        {stats.stars}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span className="font-semibold">{stats.completed} / {stats.total} levels</span>
                    </div>
                    <Progress value={progressPercent} className="h-2" />
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>

          {/* Badges Tab */}
          <TabsContent value="badges" className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {allBadges.map((badge) => {
                const isEarned = earnedBadges.includes(badge.id);

                return (
                  <Card 
                    key={badge.id} 
                    className={`${isEarned ? 'bg-card/90' : 'bg-muted/50 opacity-60'} backdrop-blur-sm`}
                  >
                    <CardContent className="p-6 text-center space-y-3">
                      <div className="text-5xl">{badge.icon}</div>
                      <h3 className="font-bold text-lg">{badge.name}</h3>
                      <p className="text-sm text-muted-foreground">{badge.description}</p>
                      {isEarned ? (
                        <Badge className="bg-success text-white">✓ Earned</Badge>
                      ) : (
                        <Badge variant="outline">Not yet earned</Badge>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
