import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Trophy, Settings, Star, Map } from 'lucide-react';
import { worlds } from '../game/content/worlds';
import type { LocalProgress } from '../progress/localProgressStore';

interface WorldSelectScreenProps {
  onSelectWorld: (worldId: string) => void;
  onOpenCollection: () => void;
  onOpenSettings: () => void;
  onOpenProgressMap: () => void;
  onBackToTitle: () => void;
  progress: LocalProgress | null;
}

export default function WorldSelectScreen({
  onSelectWorld,
  onOpenCollection,
  onOpenSettings,
  onOpenProgressMap,
  onBackToTitle,
  progress
}: WorldSelectScreenProps) {
  const getWorldProgress = (worldId: string) => {
    if (!progress) return { completed: 0, total: 0, stars: 0 };
    
    const world = worlds.find(w => w.id === worldId);
    if (!world) return { completed: 0, total: 0, stars: 0 };
    
    const worldLevels = world.levels;
    const completed = worldLevels.filter(level => 
      progress.completedLevels.some(cl => cl.levelId === level.id)
    ).length;
    
    const stars = worldLevels.reduce((sum, level) => {
      const completedLevel = progress.completedLevels.find(cl => cl.levelId === level.id);
      return sum + (completedLevel?.starsEarned || 0);
    }, 0);
    
    return { completed, total: worldLevels.length, stars };
  };

  const totalStars = progress?.completedLevels.reduce((sum, level) => sum + level.starsEarned, 0) || 0;

  return (
    <div 
      className="min-h-screen p-4 md:p-8 relative overflow-hidden"
      style={{
        backgroundImage: 'url(/assets/generated/bg-forest.dim_1920x1080.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-background/60" />
      
      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 md:mb-8 gap-2">
          <Button
            onClick={onBackToTitle}
            variant="outline"
            size="lg"
            className="bg-card/80"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back
          </Button>

          <div className="flex items-center gap-2 md:gap-4 flex-wrap justify-end">
            <Badge variant="secondary" className="text-base md:text-lg px-3 md:px-4 py-2">
              <Star className="mr-2 h-4 w-4 md:h-5 md:w-5 text-star" />
              {totalStars} Stars
            </Badge>
            <Button onClick={onOpenProgressMap} variant="outline" size="lg" className="bg-card/80">
              <Map className="mr-0 md:mr-2 h-5 w-5" />
              <span className="hidden md:inline">Progress Map</span>
            </Button>
            <Button onClick={onOpenCollection} variant="outline" size="lg" className="bg-card/80">
              <Trophy className="mr-0 md:mr-2 h-5 w-5" />
              <span className="hidden md:inline">Collection</span>
            </Button>
            <Button onClick={onOpenSettings} variant="outline" size="lg" className="bg-card/80">
              <Settings className="mr-0 md:mr-2 h-5 w-5" />
              <span className="hidden md:inline">Settings</span>
            </Button>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8 md:mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-3 md:mb-4 animate-bounce-gentle">
            Choose Your World
          </h1>
          <p className="text-lg md:text-xl text-foreground">
            Each world needs your help to restore its joy!
          </p>
        </div>

        {/* World Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {worlds.map((world) => {
            const worldProgress = getWorldProgress(world.id);
            const progressPercent = worldProgress.total > 0 
              ? (worldProgress.completed / worldProgress.total) * 100 
              : 0;

            return (
              <Card
                key={world.id}
                className="world-card bg-card/90 backdrop-blur-sm border-4 cursor-pointer transition-all hover:scale-[1.02]"
                style={{ borderColor: `oklch(var(--${world.theme}))` }}
                onClick={() => onSelectWorld(world.id)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <CardTitle className="text-2xl md:text-3xl font-bold" style={{ color: `oklch(var(--${world.theme}))` }}>
                      {world.icon} {world.name}
                    </CardTitle>
                    <Badge variant="outline" className="text-base md:text-lg">
                      <Star className="mr-1 h-4 w-4 text-star" />
                      {worldProgress.stars}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{world.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span className="font-semibold">
                        {worldProgress.completed} / {worldProgress.total} levels
                      </span>
                    </div>
                    <Progress value={progressPercent} className="h-3" />
                  </div>

                  {worldProgress.completed === worldProgress.total && worldProgress.total > 0 && (
                    <Badge className="w-full justify-center bg-success text-white">
                      ✓ World Complete!
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
