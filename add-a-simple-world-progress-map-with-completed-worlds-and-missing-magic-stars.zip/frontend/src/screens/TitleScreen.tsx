import { Button } from '@/components/ui/button';
import { Sparkles, Trophy, Settings } from 'lucide-react';

interface TitleScreenProps {
  onStartGame: () => void;
  onOpenCollection: () => void;
  onOpenSettings: () => void;
}

export default function TitleScreen({ onStartGame, onOpenCollection, onOpenSettings }: TitleScreenProps) {
  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-8 relative overflow-hidden"
      style={{
        backgroundImage: 'url(/assets/generated/bg-forest.dim_1920x1080.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* Overlay for better text readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-transparent to-background/80" />
      
      <div className="relative z-10 flex flex-col items-center gap-8 max-w-2xl">
        {/* Title */}
        <div className="text-center space-y-4 animate-slide-in-down">
          <h1 className="text-6xl md:text-8xl font-bold text-primary drop-shadow-lg animate-bounce-gentle">
            Magic Stars
          </h1>
          <p className="text-2xl md:text-3xl text-foreground font-semibold drop-shadow-md">
            Adventure Awaits! ✨
          </p>
          <p className="text-lg md:text-xl text-muted-foreground max-w-md mx-auto">
            Help bring joy back to the magical worlds by collecting lost stars!
          </p>
        </div>

        {/* Main Actions */}
        <div className="flex flex-col gap-4 w-full max-w-sm animate-slide-in-up">
          <Button
            onClick={onStartGame}
            size="lg"
            className="game-button bg-primary hover:bg-primary/90 text-primary-foreground text-2xl py-8"
          >
            <Sparkles className="mr-2 h-8 w-8" />
            Start Adventure
          </Button>

          <div className="flex gap-4">
            <Button
              onClick={onOpenCollection}
              variant="secondary"
              size="lg"
              className="game-button flex-1 bg-secondary hover:bg-secondary/90 text-secondary-foreground"
            >
              <Trophy className="mr-2 h-6 w-6" />
              Collection
            </Button>

            <Button
              onClick={onOpenSettings}
              variant="outline"
              size="lg"
              className="game-button flex-1 bg-card/80 hover:bg-card"
            >
              <Settings className="mr-2 h-6 w-6" />
              Settings
            </Button>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-20 left-10 animate-float">
          <div className="text-6xl">⭐</div>
        </div>
        <div className="absolute top-40 right-20 animate-float" style={{ animationDelay: '0.5s' }}>
          <div className="text-5xl">✨</div>
        </div>
        <div className="absolute bottom-40 left-20 animate-float" style={{ animationDelay: '1s' }}>
          <div className="text-4xl">🌟</div>
        </div>
      </div>

      {/* Footer */}
      <footer className="absolute bottom-4 text-center text-sm text-muted-foreground">
        © 2026. Built with ❤️ using{' '}
        <a href="https://caffeine.ai" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
