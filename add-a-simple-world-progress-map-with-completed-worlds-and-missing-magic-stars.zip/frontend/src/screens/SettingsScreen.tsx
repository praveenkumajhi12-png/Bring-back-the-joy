import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ArrowLeft, Volume2, Music, RotateCcw } from 'lucide-react';
import { useAudioSettings } from '../audio/useAudioSettings';
import { useProgressSync } from '../progress/useProgressSync';
import LoginButton from '../auth/LoginButton';

interface SettingsScreenProps {
  onClose: () => void;
}

export default function SettingsScreen({ onClose }: SettingsScreenProps) {
  const { settings, updateSettings } = useAudioSettings();
  const { resetProgress } = useProgressSync();

  const handleResetProgress = () => {
    resetProgress();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/10 to-background p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button onClick={onClose} variant="outline" size="lg">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back
          </Button>
          <h1 className="text-4xl md:text-5xl font-bold text-primary">Settings</h1>
          <div className="w-24" />
        </div>

        <div className="space-y-6">
          {/* Audio Settings */}
          <Card className="bg-card/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="h-6 w-6" />
                Audio Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Music Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="music-toggle" className="text-lg">Background Music</Label>
                <Switch
                  id="music-toggle"
                  checked={settings.musicEnabled}
                  onCheckedChange={(checked) => updateSettings({ musicEnabled: checked })}
                />
              </div>

              {/* Music Volume */}
              <div className="space-y-2">
                <Label htmlFor="music-volume" className="text-lg flex items-center gap-2">
                  <Music className="h-5 w-5" />
                  Music Volume
                </Label>
                <Slider
                  id="music-volume"
                  value={[settings.musicVolume * 100]}
                  onValueChange={(value) => updateSettings({ musicVolume: value[0] / 100 })}
                  max={100}
                  step={1}
                  disabled={!settings.musicEnabled}
                  className="w-full"
                />
                <p className="text-sm text-muted-foreground text-right">{Math.round(settings.musicVolume * 100)}%</p>
              </div>

              {/* SFX Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="sfx-toggle" className="text-lg">Sound Effects</Label>
                <Switch
                  id="sfx-toggle"
                  checked={settings.sfxEnabled}
                  onCheckedChange={(checked) => updateSettings({ sfxEnabled: checked })}
                />
              </div>

              {/* SFX Volume */}
              <div className="space-y-2">
                <Label htmlFor="sfx-volume" className="text-lg flex items-center gap-2">
                  <Volume2 className="h-5 w-5" />
                  Sound Effects Volume
                </Label>
                <Slider
                  id="sfx-volume"
                  value={[settings.sfxVolume * 100]}
                  onValueChange={(value) => updateSettings({ sfxVolume: value[0] / 100 })}
                  max={100}
                  step={1}
                  disabled={!settings.sfxEnabled}
                  className="w-full"
                />
                <p className="text-sm text-muted-foreground text-right">{Math.round(settings.sfxVolume * 100)}%</p>
              </div>
            </CardContent>
          </Card>

          {/* Account Settings */}
          <Card className="bg-card/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Account</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">Internet Identity</p>
                  <p className="text-sm text-muted-foreground">Sign in to save your progress across devices</p>
                </div>
                <LoginButton />
              </div>
            </CardContent>
          </Card>

          {/* Progress Settings */}
          <Card className="bg-card/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RotateCcw className="h-6 w-6" />
                Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    Reset All Progress
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset all your progress, including completed levels, stars, and badges. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleResetProgress} className="bg-destructive text-destructive-foreground">
                      Reset Progress
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
