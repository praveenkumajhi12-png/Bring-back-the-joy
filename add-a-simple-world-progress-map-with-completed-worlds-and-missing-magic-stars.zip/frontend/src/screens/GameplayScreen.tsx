import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, RotateCcw, Star } from 'lucide-react';
import { getLevelById } from '../game/levels/registry';
import ResultsOverlay from './ResultsOverlay';
import ControlsHelpPanel from '../game/ui/ControlsHelpPanel';
import { useProgressSync } from '../progress/useProgressSync';
import { useAudioManager } from '../audio/useAudioManager';

interface GameplayScreenProps {
  levelId: string;
  onComplete: () => void;
  onBack: () => void;
}

export default function GameplayScreen({ levelId, onComplete, onBack }: GameplayScreenProps) {
  const [showResults, setShowResults] = useState(false);
  const [levelResult, setLevelResult] = useState<{ starsEarned: number; timeTaken: number; badges: string[] } | null>(null);
  const [key, setKey] = useState(0);
  const [starsCollected, setStarsCollected] = useState(0);
  
  const { completeLevel } = useProgressSync();
  const { playSfx } = useAudioManager();
  const level = getLevelById(levelId);

  useEffect(() => {
    playSfx('gameplay');
  }, [playSfx]);

  if (!level) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Level not found</p>
      </div>
    );
  }

  const handleLevelComplete = (result: { starsEarned: number; timeTaken: number; badges?: string[] }) => {
    setLevelResult({
      starsEarned: result.starsEarned,
      timeTaken: result.timeTaken,
      badges: result.badges || []
    });
    setShowResults(true);
    playSfx('complete');
    completeLevel(levelId, result.starsEarned, result.timeTaken, result.badges || []);
  };

  const handleRestart = () => {
    setKey(prev => prev + 1);
    setStarsCollected(0);
    playSfx('click');
  };

  const handleContinue = () => {
    setShowResults(false);
    onComplete();
  };

  const handleStarCollect = () => {
    setStarsCollected(prev => prev + 1);
    playSfx('star');
  };

  const LevelComponent = level.component;

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/10 to-background relative">
      {/* HUD */}
      <div className="absolute top-0 left-0 right-0 z-20 bg-card/80 backdrop-blur-sm border-b-4 border-primary/20 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Button onClick={onBack} variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>

          <div className="flex items-center gap-4">
            <div className="text-lg font-bold">{level.name}</div>
            <div className="flex items-center gap-1">
              <Star className="h-5 w-5 text-star fill-star" />
              <span className="font-bold">{starsCollected}</span>
            </div>
          </div>

          <Button onClick={handleRestart} variant="outline" size="sm">
            <RotateCcw className="mr-2 h-4 w-4" />
            Restart
          </Button>
        </div>
      </div>

      {/* Controls Help */}
      <div className="absolute top-24 right-4 z-20">
        <ControlsHelpPanel levelType={level.type} />
      </div>

      {/* Game Content */}
      <div className="pt-20 pb-8 px-4">
        <LevelComponent
          key={key}
          onComplete={handleLevelComplete}
          onStarCollect={handleStarCollect}
        />
      </div>

      {/* Results Overlay */}
      {showResults && levelResult && (
        <ResultsOverlay
          levelName={level.name}
          starsEarned={levelResult.starsEarned}
          timeTaken={levelResult.timeTaken}
          badges={levelResult.badges}
          onContinue={handleContinue}
        />
      )}
    </div>
  );
}
