import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight, SkipForward } from 'lucide-react';

interface IntroSequenceProps {
  onComplete: () => void;
  onSkip: () => void;
}

const introSlides = [
  {
    text: "Welcome, brave hero! 🌟",
    subtext: "The magical worlds need your help!"
  },
  {
    text: "Long ago, magic stars brought joy to every world... ✨",
    subtext: "But one day, they were lost and scattered!"
  },
  {
    text: "Without the stars, the worlds lost their happiness. 😢",
    subtext: "Only a kind heart can bring them back!"
  },
  {
    text: "Travel through wonderful worlds! 🌈",
    subtext: "Help friendly characters and solve fun puzzles!"
  },
  {
    text: "Collect the magic stars to restore joy! ⭐",
    subtext: "Your adventure begins now!"
  }
];

export default function IntroSequence({ onComplete, onSkip }: IntroSequenceProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < introSlides.length - 1) {
      setCurrentSlide(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const slide = introSlides[currentSlide];

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8 relative overflow-hidden"
      style={{
        backgroundImage: 'url(/assets/generated/bg-forest.dim_1920x1080.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-background/70" />

      <div className="relative z-10 max-w-2xl w-full">
        <Card className="bg-card/95 backdrop-blur-sm animate-slide-in-up">
          <CardContent className="p-12 space-y-8">
            {/* Slide Content */}
            <div className="text-center space-y-4">
              <h2 className="text-4xl md:text-5xl font-bold text-primary animate-bounce-gentle">
                {slide.text}
              </h2>
              <p className="text-xl md:text-2xl text-foreground">
                {slide.subtext}
              </p>
            </div>

            {/* Progress Dots */}
            <div className="flex justify-center gap-2">
              {introSlides.map((_, index) => (
                <div
                  key={index}
                  className={`h-3 rounded-full transition-all ${
                    index === currentSlide 
                      ? 'w-8 bg-primary' 
                      : 'w-3 bg-muted-foreground/30'
                  }`}
                />
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-4">
              <Button
                onClick={onSkip}
                variant="outline"
                size="lg"
                className="flex-1"
              >
                <SkipForward className="mr-2 h-5 w-5" />
                Skip
              </Button>
              <Button
                onClick={handleNext}
                size="lg"
                className="flex-1 game-button bg-primary hover:bg-primary/90"
              >
                {currentSlide < introSlides.length - 1 ? (
                  <>
                    Next
                    <ChevronRight className="ml-2 h-5 w-5" />
                  </>
                ) : (
                  "Start Adventure!"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
