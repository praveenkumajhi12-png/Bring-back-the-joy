import { useState, useEffect } from 'react';
import { ThemeProvider } from 'next-themes';
import TitleScreen from './screens/TitleScreen';
import WorldSelectScreen from './screens/WorldSelectScreen';
import LevelSelectScreen from './screens/LevelSelectScreen';
import GameplayScreen from './screens/GameplayScreen';
import CollectionScreen from './screens/CollectionScreen';
import SettingsScreen from './screens/SettingsScreen';
import ProgressMapScreen from './screens/ProgressMapScreen';
import IntroSequence from './story/IntroSequence';
import WorldIntroDialog from './screens/WorldIntroDialog';
import ProfileGate from './auth/ProfileGate';
import { useProgressSync } from './progress/useProgressSync';
import { useAudioManager } from './audio/useAudioManager';
import { Toaster } from './components/ui/sonner';

export type GameScreen = 'title' | 'intro' | 'worldSelect' | 'levelSelect' | 'gameplay' | 'collection' | 'settings' | 'progressMap';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('title');
  const [selectedWorld, setSelectedWorld] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [showWorldIntro, setShowWorldIntro] = useState(false);
  const [hasSeenIntro, setHasSeenIntro] = useState(false);

  const { progress, isLoading: progressLoading } = useProgressSync();
  const { initAudio } = useAudioManager();

  useEffect(() => {
    // Check if user has seen intro
    const introSeen = localStorage.getItem('hasSeenIntro');
    if (introSeen === 'true') {
      setHasSeenIntro(true);
    }
  }, []);

  const handleStartGame = () => {
    if (!hasSeenIntro) {
      setCurrentScreen('intro');
    } else {
      setCurrentScreen('worldSelect');
    }
    initAudio();
  };

  const handleSkipIntro = () => {
    localStorage.setItem('hasSeenIntro', 'true');
    setHasSeenIntro(true);
    setCurrentScreen('worldSelect');
  };

  const handleSelectWorld = (worldId: string) => {
    setSelectedWorld(worldId);
    
    // Check if this is the first time visiting this world
    const worldKey = `worldIntro_${worldId}`;
    const hasSeenWorldIntro = localStorage.getItem(worldKey);
    
    if (!hasSeenWorldIntro) {
      setShowWorldIntro(true);
      localStorage.setItem(worldKey, 'true');
    } else {
      setCurrentScreen('levelSelect');
    }
  };

  const handleWorldIntroComplete = () => {
    setShowWorldIntro(false);
    setCurrentScreen('levelSelect');
  };

  const handleSelectLevel = (levelId: string) => {
    setSelectedLevel(levelId);
    setCurrentScreen('gameplay');
  };

  const handleLevelComplete = () => {
    setCurrentScreen('levelSelect');
  };

  const handleBackToWorldSelect = () => {
    setSelectedWorld(null);
    setCurrentScreen('worldSelect');
  };

  const handleBackToTitle = () => {
    setCurrentScreen('title');
  };

  const handleOpenCollection = () => {
    setCurrentScreen('collection');
  };

  const handleOpenSettings = () => {
    setCurrentScreen('settings');
  };

  const handleOpenProgressMap = () => {
    setCurrentScreen('progressMap');
  };

  const handleCloseCollection = () => {
    setCurrentScreen('worldSelect');
  };

  const handleCloseSettings = () => {
    if (currentScreen === 'settings') {
      setCurrentScreen('title');
    }
  };

  const handleCloseProgressMap = () => {
    setCurrentScreen('worldSelect');
  };

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
      <ProfileGate>
        <div className="min-h-screen bg-background">
          {currentScreen === 'title' && (
            <TitleScreen
              onStartGame={handleStartGame}
              onOpenCollection={handleOpenCollection}
              onOpenSettings={handleOpenSettings}
            />
          )}

          {currentScreen === 'intro' && (
            <IntroSequence
              onComplete={handleSkipIntro}
              onSkip={handleSkipIntro}
            />
          )}

          {currentScreen === 'worldSelect' && (
            <WorldSelectScreen
              onSelectWorld={handleSelectWorld}
              onOpenCollection={handleOpenCollection}
              onOpenSettings={handleOpenSettings}
              onOpenProgressMap={handleOpenProgressMap}
              onBackToTitle={handleBackToTitle}
              progress={progress}
            />
          )}

          {currentScreen === 'levelSelect' && selectedWorld && (
            <LevelSelectScreen
              worldId={selectedWorld}
              onSelectLevel={handleSelectLevel}
              onBack={handleBackToWorldSelect}
              progress={progress}
            />
          )}

          {currentScreen === 'gameplay' && selectedLevel && (
            <GameplayScreen
              levelId={selectedLevel}
              onComplete={handleLevelComplete}
              onBack={handleBackToWorldSelect}
            />
          )}

          {currentScreen === 'collection' && (
            <CollectionScreen
              onClose={handleCloseCollection}
              progress={progress}
            />
          )}

          {currentScreen === 'settings' && (
            <SettingsScreen onClose={handleCloseSettings} />
          )}

          {currentScreen === 'progressMap' && (
            <ProgressMapScreen
              progress={progress}
              onBack={handleCloseProgressMap}
            />
          )}

          {showWorldIntro && selectedWorld && (
            <WorldIntroDialog
              worldId={selectedWorld}
              onComplete={handleWorldIntroComplete}
            />
          )}

          <Toaster />
        </div>
      </ProfileGate>
    </ThemeProvider>
  );
}
