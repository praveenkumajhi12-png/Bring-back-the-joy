import { useEffect, useState } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetMyProgress, useUpdateLevel, useAddBadge, useResetMyProgress } from '../hooks/useQueries';
import { getLocalProgress, saveLocalProgress, resetLocalProgress, type LocalProgress } from './localProgressStore';
import { toast } from 'sonner';

export function useProgressSync() {
  const { identity } = useInternetIdentity();
  const { data: backendProgress, isLoading: backendLoading } = useGetMyProgress();
  const updateLevelMutation = useUpdateLevel();
  const addBadgeMutation = useAddBadge();
  const resetProgressMutation = useResetMyProgress();
  
  const [localProgress, setLocalProgress] = useState<LocalProgress | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const isAuthenticated = !!identity;

  // Load progress on mount and when auth changes
  useEffect(() => {
    if (isAuthenticated && backendProgress) {
      // Convert backend progress to local format
      const converted: LocalProgress = {
        completedLevels: backendProgress.completedLevels.map(level => ({
          levelId: `level-${Number(level.levelNumber)}`,
          starsEarned: Number(level.starsEarned),
          timeTaken: Number(level.timeTaken)
        })),
        badges: backendProgress.badges
      };
      setLocalProgress(converted);
      setIsLoading(false);
    } else if (!isAuthenticated) {
      // Load from localStorage for guest
      const local = getLocalProgress();
      setLocalProgress(local);
      setIsLoading(false);
    } else if (isAuthenticated && !backendLoading) {
      // Authenticated but no backend progress yet
      setLocalProgress({ completedLevels: [], badges: [] });
      setIsLoading(false);
    }
  }, [isAuthenticated, backendProgress, backendLoading]);

  const completeLevel = async (levelId: string, starsEarned: number, timeTaken: number, badges: string[] = []) => {
    // Extract level number from levelId (format: "level-X" or "world-level-X")
    const levelNumber = parseInt(levelId.split('-').pop() || '0');

    // Update local state immediately
    const updatedProgress: LocalProgress = {
      completedLevels: [
        ...(localProgress?.completedLevels.filter(cl => cl.levelId !== levelId) || []),
        { levelId, starsEarned, timeTaken }
      ],
      badges: [...new Set([...(localProgress?.badges || []), ...badges])]
    };
    setLocalProgress(updatedProgress);

    // Save to appropriate storage
    if (isAuthenticated) {
      try {
        await updateLevelMutation.mutateAsync({ levelNumber, starsEarned, timeTaken });
        for (const badge of badges) {
          await addBadgeMutation.mutateAsync(badge);
        }
      } catch (error) {
        console.error('Failed to save progress to backend:', error);
        toast.error('Failed to save progress online. Progress saved locally.');
        saveLocalProgress(updatedProgress);
      }
    } else {
      saveLocalProgress(updatedProgress);
    }
  };

  const resetProgress = async () => {
    if (isAuthenticated) {
      try {
        await resetProgressMutation.mutateAsync();
        setLocalProgress({ completedLevels: [], badges: [] });
        toast.success('Progress reset successfully!');
      } catch (error) {
        console.error('Failed to reset backend progress:', error);
        toast.error('Failed to reset online progress.');
      }
    } else {
      resetLocalProgress();
      setLocalProgress({ completedLevels: [], badges: [] });
      toast.success('Progress reset successfully!');
    }
  };

  return {
    progress: localProgress,
    isLoading,
    completeLevel,
    resetProgress
  };
}
