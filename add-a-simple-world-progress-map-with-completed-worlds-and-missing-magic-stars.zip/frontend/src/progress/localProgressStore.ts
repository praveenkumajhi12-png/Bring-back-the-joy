export interface LocalProgress {
  completedLevels: Array<{
    levelId: string;
    starsEarned: number;
    timeTaken: number;
  }>;
  badges: string[];
}

const STORAGE_KEY = 'magicStars_progress';

export function getLocalProgress(): LocalProgress {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Failed to load local progress:', error);
  }
  return { completedLevels: [], badges: [] };
}

export function saveLocalProgress(progress: LocalProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (error) {
    console.error('Failed to save local progress:', error);
  }
}

export function resetLocalProgress(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Failed to reset local progress:', error);
  }
}
