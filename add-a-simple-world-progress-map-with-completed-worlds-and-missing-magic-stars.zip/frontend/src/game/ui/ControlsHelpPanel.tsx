import { Card, CardContent } from '@/components/ui/card';
import { Keyboard, MousePointer, Hand } from 'lucide-react';

interface ControlsHelpPanelProps {
  levelType: string;
}

export default function ControlsHelpPanel({ levelType }: ControlsHelpPanelProps) {
  const getControls = () => {
    switch (levelType) {
      case 'Platform':
        return {
          keyboard: 'Arrow keys to move and jump',
          mouse: 'Click to jump',
          touch: 'Tap to jump'
        };
      case 'Path Finding':
        return {
          keyboard: 'Arrow keys to move',
          mouse: 'Click tiles to move',
          touch: 'Swipe to move'
        };
      default:
        return {
          keyboard: 'Arrow keys to navigate',
          mouse: 'Click to select',
          touch: 'Tap to select'
        };
    }
  };

  const controls = getControls();

  return (
    <Card className="bg-card/90 backdrop-blur-sm w-64">
      <CardContent className="p-4 space-y-3">
        <h3 className="font-bold text-sm text-center mb-2">How to Play</h3>
        
        <div className="space-y-2 text-xs">
          <div className="flex items-start gap-2">
            <Keyboard className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
            <span>{controls.keyboard}</span>
          </div>
          
          <div className="flex items-start gap-2">
            <MousePointer className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
            <span>{controls.mouse}</span>
          </div>
          
          <div className="flex items-start gap-2">
            <Hand className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
            <span>{controls.touch}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
