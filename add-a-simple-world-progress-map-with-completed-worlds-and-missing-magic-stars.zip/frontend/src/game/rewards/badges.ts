export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  criteria: string;
}

export const allBadges: Badge[] = [
  {
    id: 'kind-helper',
    name: 'Kind Helper',
    description: 'Complete your first level',
    icon: '💚',
    criteria: 'complete_first_level'
  },
  {
    id: 'memory-master',
    name: 'Memory Master',
    description: 'Complete a memory level perfectly',
    icon: '🧠',
    criteria: 'memory_perfect'
  },
  {
    id: 'math-star',
    name: 'Math Star',
    description: 'Get all counting puzzles correct',
    icon: '🔢',
    criteria: 'counting_perfect'
  },
  {
    id: 'pattern-pro',
    name: 'Pattern Pro',
    description: 'Complete a matching level with 3 stars',
    icon: '🎨',
    criteria: 'matching_3_stars'
  },
  {
    id: 'quick-thinker',
    name: 'Quick Thinker',
    description: 'Complete a level in under 30 seconds',
    icon: '⚡',
    criteria: 'speed_30s'
  },
  {
    id: 'star-collector',
    name: 'Star Collector',
    description: 'Collect 50 stars total',
    icon: '⭐',
    criteria: 'total_50_stars'
  },
  {
    id: 'world-explorer',
    name: 'World Explorer',
    description: 'Visit all four worlds',
    icon: '🌍',
    criteria: 'visit_all_worlds'
  },
  {
    id: 'perfect-helper',
    name: 'Perfect Helper',
    description: 'Complete a world with all 3-star ratings',
    icon: '🏆',
    criteria: 'world_all_3_stars'
  }
];

export function checkBadgeEarned(badgeId: string, context: {
  isFirstLevel?: boolean;
  isPerfect?: boolean;
  starsEarned?: number;
  timeTaken?: number;
  levelType?: string;
  totalStars?: number;
}): boolean {
  const badge = allBadges.find(b => b.id === badgeId);
  if (!badge) return false;

  switch (badge.criteria) {
    case 'complete_first_level':
      return context.isFirstLevel === true;
    case 'memory_perfect':
      return context.levelType === 'Memory' && context.isPerfect === true;
    case 'counting_perfect':
      return context.levelType === 'Counting' && context.isPerfect === true;
    case 'matching_3_stars':
      return context.levelType === 'Matching' && context.starsEarned === 3;
    case 'speed_30s':
      return (context.timeTaken || 999) < 30;
    case 'total_50_stars':
      return (context.totalStars || 0) >= 50;
    default:
      return false;
  }
}
