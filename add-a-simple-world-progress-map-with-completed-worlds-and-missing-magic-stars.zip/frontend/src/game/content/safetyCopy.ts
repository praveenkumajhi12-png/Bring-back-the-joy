export const safetyCopy = {
  success: [
    "Amazing work! You're a star! ⭐",
    "Fantastic! Keep going! 🌟",
    "You did it! Great job! ✨",
    "Wonderful! You're so clever! 💫",
    "Perfect! You're amazing! 🎉"
  ],
  tryAgain: [
    "Almost there! Try again! 😊",
    "Good try! You can do it! 💪",
    "Keep trying! You're learning! 🌈",
    "Nice effort! Give it another go! ⭐",
    "Don't give up! You're doing great! 🌟"
  ],
  hints: [
    "Take your time and think carefully! 🤔",
    "Look closely at the patterns! 👀",
    "Remember what you learned! 💡",
    "You've got this! Believe in yourself! ✨",
    "Try a different approach! 🎯"
  ],
  resetConfirm: "Are you sure you want to start over? Your progress will be saved!",
  levelComplete: "Level complete! You brought joy back to this place! 🎉"
};
