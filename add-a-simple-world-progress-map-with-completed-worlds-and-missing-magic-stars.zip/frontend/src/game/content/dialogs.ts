export interface WorldDialog {
  npcIcon: string;
  npcName: string;
  greeting: string;
  problem: string;
  request: string;
  positiveValue: string;
}

export const worldDialogs: Record<string, WorldDialog> = {
  forest: {
    npcIcon: '🦊',
    npcName: 'Friendly Fox',
    greeting: 'Hello, kind friend! Welcome to the Enchanted Forest!',
    problem: 'Our forest has lost its sparkle. The magic stars that made everything bloom are missing!',
    request: 'Will you help us find the stars and bring back the joy?',
    positiveValue: 'Kindness: Helping others brings happiness to everyone!'
  },
  candy: {
    npcIcon: '🍰',
    npcName: 'Sweet Baker',
    greeting: 'Hi there, wonderful helper! Welcome to Candy Land!',
    problem: 'Our candy has lost its sweetness! The magic stars that made everything delicious are gone!',
    request: 'Can you help us collect the stars and make our world sweet again?',
    positiveValue: 'Teamwork: Together we can solve any problem!'
  },
  sky: {
    npcIcon: '🦅',
    npcName: 'Sky Guardian',
    greeting: 'Greetings, brave adventurer! Welcome to Sky City!',
    problem: 'The clouds are sad because the magic stars that kept us floating are missing!',
    request: 'Would you help us find the stars and restore our sky home?',
    positiveValue: 'Helping Others: When we help, everyone feels better!'
  },
  ocean: {
    npcIcon: '🐬',
    npcName: 'Dolphin Friend',
    greeting: 'Hello, amazing friend! Welcome to Ocean World!',
    problem: 'The ocean is dim without the magic stars that made our waters sparkle!',
    request: 'Will you dive with us to find the stars and light up our home?',
    positiveValue: 'Kindness: Small acts of kindness create big waves of joy!'
  }
};
