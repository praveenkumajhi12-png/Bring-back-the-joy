export interface Level {
  id: string;
  levelNumber: number;
  name: string;
  type: string;
  icon: string;
}

export interface World {
  id: string;
  name: string;
  icon: string;
  description: string;
  theme: string;
  backgroundImage: string;
  levels: Level[];
}

export const worlds: World[] = [
  {
    id: 'forest',
    name: 'Enchanted Forest',
    icon: '🌳',
    description: 'A magical forest where friendly animals need your help!',
    theme: 'forest',
    backgroundImage: 'forest',
    levels: [
      { id: 'forest-level-1', levelNumber: 1, name: 'Match the Flowers', type: 'Matching', icon: '🌸' },
      { id: 'forest-level-2', levelNumber: 2, name: 'Count the Butterflies', type: 'Counting', icon: '🦋' },
      { id: 'forest-level-3', levelNumber: 3, name: 'Memory Garden', type: 'Memory', icon: '🌺' }
    ]
  },
  {
    id: 'candy',
    name: 'Candy Land',
    icon: '🍭',
    description: 'A sweet world full of treats and friendly candy characters!',
    theme: 'candy',
    backgroundImage: 'candyland',
    levels: [
      { id: 'candy-level-1', levelNumber: 4, name: 'Sweet Matching', type: 'Matching', icon: '🍬' },
      { id: 'candy-level-2', levelNumber: 5, name: 'Candy Counter', type: 'Counting', icon: '🍫' },
      { id: 'candy-level-3', levelNumber: 6, name: 'Gumdrop Path', type: 'Path Finding', icon: '🍡' }
    ]
  },
  {
    id: 'sky',
    name: 'Sky City',
    icon: '☁️',
    description: 'Float through clouds and help the sky dwellers!',
    theme: 'sky',
    backgroundImage: 'skycity',
    levels: [
      { id: 'sky-level-1', levelNumber: 7, name: 'Cloud Jumper', type: 'Platform', icon: '⛅' },
      { id: 'sky-level-2', levelNumber: 8, name: 'Sky Memory', type: 'Memory', icon: '🌤️' }
    ]
  },
  {
    id: 'ocean',
    name: 'Ocean World',
    icon: '🌊',
    description: 'Dive deep and meet wonderful sea creatures!',
    theme: 'ocean',
    backgroundImage: 'ocean',
    levels: [
      { id: 'ocean-level-1', levelNumber: 9, name: 'Shell Matching', type: 'Matching', icon: '🐚' },
      { id: 'ocean-level-2', levelNumber: 10, name: 'Fish Counter', type: 'Counting', icon: '🐠' },
      { id: 'ocean-level-3', levelNumber: 11, name: 'Coral Maze', type: 'Path Finding', icon: '🪸' }
    ]
  }
];
