import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAudioManager } from '../../audio/useAudioManager';

interface PathGridLevelProps {
  onComplete: (result: { starsEarned: number; timeTaken: number }) => void;
  onStarCollect?: () => void;
}

export default function PathGridLevel({ onComplete, onStarCollect }: PathGridLevelProps) {
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [goalPos] = useState({ x: 4, y: 4 });
  const [moves, setMoves] = useState(0);
  const [startTime] = useState(Date.now());
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  const { playSfx } = useAudioManager();

  const gridSize = 5;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let newX = playerPos.x;
      let newY = playerPos.y;

      if (e.key === 'ArrowUp') newY = Math.max(0, playerPos.y - 1);
      if (e.key === 'ArrowDown') newY = Math.min(gridSize - 1, playerPos.y + 1);
      if (e.key === 'ArrowLeft') newX = Math.max(0, playerPos.x - 1);
      if (e.key === 'ArrowRight') newX = Math.min(gridSize - 1, playerPos.x + 1);

      if (newX !== playerPos.x || newY !== playerPos.y) {
        setPlayerPos({ x: newX, y: newY });
        setMoves(prev => prev + 1);
        playSfx('click');
        
        if (newX === goalPos.x && newY === goalPos.y) {
          handleWin();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playerPos, goalPos, playSfx]);

  const handleWin = () => {
    if (onStarCollect) onStarCollect();
    playSfx('star');
    const timeTaken = Math.floor((Date.now() - startTime) / 1000);
    const starsEarned = moves <= 8 ? 3 : moves <= 12 ? 2 : 1;
    setTimeout(() => {
      onComplete({ starsEarned, timeTaken });
    }, 500);
  };

  const handleCellClick = (x: number, y: number) => {
    // Only allow adjacent moves
    const dx = Math.abs(x - playerPos.x);
    const dy = Math.abs(y - playerPos.y);
    
    if ((dx === 1 && dy === 0) || (dx === 0 && dy === 1)) {
      setPlayerPos({ x, y });
      setMoves(prev => prev + 1);
      playSfx('click');
      
      if (x === goalPos.x && y === goalPos.y) {
        handleWin();
      }
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchStart({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStart) return;
    
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStart.x;
    const dy = touch.clientY - touchStart.y;
    
    const threshold = 30;
    let newX = playerPos.x;
    let newY = playerPos.y;
    
    if (Math.abs(dx) > Math.abs(dy)) {
      // Horizontal swipe
      if (Math.abs(dx) > threshold) {
        if (dx > 0) newX = Math.min(gridSize - 1, playerPos.x + 1);
        else newX = Math.max(0, playerPos.x - 1);
      }
    } else {
      // Vertical swipe
      if (Math.abs(dy) > threshold) {
        if (dy > 0) newY = Math.min(gridSize - 1, playerPos.y + 1);
        else newY = Math.max(0, playerPos.y - 1);
      }
    }
    
    if (newX !== playerPos.x || newY !== playerPos.y) {
      setPlayerPos({ x: newX, y: newY });
      setMoves(prev => prev + 1);
      playSfx('click');
      
      if (newX === goalPos.x && newY === goalPos.y) {
        handleWin();
      }
    }
    
    setTouchStart(null);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card/90 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">Find the Path!</h2>
            <p className="text-muted-foreground">Reach the goal star 🌟</p>
            <p className="text-sm text-muted-foreground mt-2">Moves: {moves}</p>
          </div>

          <div 
            className="grid gap-2 mx-auto max-w-md"
            style={{ gridTemplateColumns: `repeat(${gridSize}, 1fr)` }}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            {Array.from({ length: gridSize * gridSize }).map((_, index) => {
              const x = index % gridSize;
              const y = Math.floor(index / gridSize);
              const isPlayer = x === playerPos.x && y === playerPos.y;
              const isGoal = x === goalPos.x && y === goalPos.y;
              const isAdjacent = 
                (Math.abs(x - playerPos.x) === 1 && y === playerPos.y) ||
                (Math.abs(y - playerPos.y) === 1 && x === playerPos.x);

              return (
                <Button
                  key={index}
                  onClick={() => handleCellClick(x, y)}
                  className={`h-16 text-3xl ${
                    isPlayer ? 'bg-primary text-primary-foreground' :
                    isGoal ? 'bg-warning text-white' :
                    isAdjacent ? 'bg-muted hover:bg-muted/80' :
                    'bg-muted/50 cursor-default'
                  }`}
                  disabled={!isAdjacent && !isPlayer && !isGoal}
                >
                  {isPlayer ? '😊' : isGoal ? '⭐' : ''}
                </Button>
              );
            })}
          </div>

          <div className="text-center mt-6 text-sm text-muted-foreground">
            <p>Use arrow keys, click adjacent tiles, or swipe to move!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
