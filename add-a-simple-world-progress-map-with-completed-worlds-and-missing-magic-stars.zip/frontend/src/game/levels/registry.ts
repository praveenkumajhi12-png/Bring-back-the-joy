import MatchingItemsLevel from './MatchingItemsLevel';
import CountingObjectsLevel from './CountingObjectsLevel';
import MemoryFlipCardsLevel from './MemoryFlipCardsLevel';
import GentlePlatformStarsLevel from './GentlePlatformStarsLevel';
import PathGridLevel from './PathGridLevel';

export interface LevelDefinition {
  id: string;
  name: string;
  type: string;
  component: React.ComponentType<any>;
}

const levelRegistry: Record<string, LevelDefinition> = {
  'forest-level-1': {
    id: 'forest-level-1',
    name: 'Match the Flowers',
    type: 'Matching',
    component: MatchingItemsLevel
  },
  'forest-level-2': {
    id: 'forest-level-2',
    name: 'Count the Butterflies',
    type: 'Counting',
    component: CountingObjectsLevel
  },
  'forest-level-3': {
    id: 'forest-level-3',
    name: 'Memory Garden',
    type: 'Memory',
    component: MemoryFlipCardsLevel
  },
  'candy-level-1': {
    id: 'candy-level-1',
    name: 'Sweet Matching',
    type: 'Matching',
    component: MatchingItemsLevel
  },
  'candy-level-2': {
    id: 'candy-level-2',
    name: 'Candy Counter',
    type: 'Counting',
    component: CountingObjectsLevel
  },
  'candy-level-3': {
    id: 'candy-level-3',
    name: 'Gumdrop Path',
    type: 'Path Finding',
    component: PathGridLevel
  },
  'sky-level-1': {
    id: 'sky-level-1',
    name: 'Cloud Jumper',
    type: 'Platform',
    component: GentlePlatformStarsLevel
  },
  'sky-level-2': {
    id: 'sky-level-2',
    name: 'Sky Memory',
    type: 'Memory',
    component: MemoryFlipCardsLevel
  },
  'ocean-level-1': {
    id: 'ocean-level-1',
    name: 'Shell Matching',
    type: 'Matching',
    component: MatchingItemsLevel
  },
  'ocean-level-2': {
    id: 'ocean-level-2',
    name: 'Fish Counter',
    type: 'Counting',
    component: CountingObjectsLevel
  },
  'ocean-level-3': {
    id: 'ocean-level-3',
    name: 'Coral Maze',
    type: 'Path Finding',
    component: PathGridLevel
  }
};

export function getLevelById(levelId: string): LevelDefinition | null {
  return levelRegistry[levelId] || null;
}
