import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAudioManager } from '../../audio/useAudioManager';
import { safetyCopy } from '../content/safetyCopy';

interface MatchingItemsLevelProps {
  onComplete: (result: { starsEarned: number; timeTaken: number; badges?: string[] }) => void;
  onStarCollect?: () => void;
}

const items = ['🌸', '🌺', '🌻', '🌷', '🌹', '🌼'];

export default function MatchingItemsLevel({ onComplete, onStarCollect }: MatchingItemsLevelProps) {
  const [pairs, setPairs] = useState<string[]>([]);
  const [selected, setSelected] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [startTime] = useState(Date.now());
  const [attempts, setAttempts] = useState(0);
  const { playSfx } = useAudioManager();

  useEffect(() => {
    // Create pairs
    const selectedItems = items.slice(0, 6);
    const pairArray = [...selectedItems, ...selectedItems];
    // Shuffle
    const shuffled = pairArray.sort(() => Math.random() - 0.5);
    setPairs(shuffled);
  }, []);

  const handleSelect = (index: number) => {
    if (selected.length >= 2 || matched.includes(index) || selected.includes(index)) return;

    const newSelected = [...selected, index];
    setSelected(newSelected);
    playSfx('click');

    if (newSelected.length === 2) {
      setAttempts(prev => prev + 1);
      const [first, second] = newSelected;
      
      if (pairs[first] === pairs[second]) {
        // Match!
        playSfx('correct');
        const newMatched = [...matched, first, second];
        setMatched(newMatched);
        setSelected([]);
        
        if (onStarCollect) onStarCollect();

        // Check if all matched
        if (newMatched.length === pairs.length) {
          const timeTaken = Math.floor((Date.now() - startTime) / 1000);
          const starsEarned = attempts <= 8 ? 3 : attempts <= 12 ? 2 : 1;
          setTimeout(() => {
            onComplete({ starsEarned, timeTaken, badges: starsEarned === 3 ? ['pattern-pro'] : [] });
          }, 500);
        }
      } else {
        // No match
        playSfx('incorrect');
        setTimeout(() => setSelected([]), 800);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card/90 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">Match the Pairs!</h2>
            <p className="text-muted-foreground">Find all the matching flowers 🌸</p>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 mb-6">
            {pairs.map((item, index) => {
              const isSelected = selected.includes(index);
              const isMatched = matched.includes(index);
              const isVisible = isSelected || isMatched;

              return (
                <Button
                  key={index}
                  onClick={() => handleSelect(index)}
                  disabled={isMatched}
                  className={`h-24 text-5xl ${
                    isMatched ? 'bg-success/20 cursor-default' : 
                    isSelected ? 'bg-primary/20' : 
                    'bg-muted hover:bg-muted/80'
                  }`}
                >
                  {isVisible ? item : '?'}
                </Button>
              );
            })}
          </div>

          <div className="text-center text-sm text-muted-foreground">
            Attempts: {attempts}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
