import { useState, useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { useAudioManager } from '../../audio/useAudioManager';

interface GentlePlatformStarsLevelProps {
  onComplete: (result: { starsEarned: number; timeTaken: number }) => void;
  onStarCollect?: () => void;
}

export default function GentlePlatformStarsLevel({ onComplete, onStarCollect }: GentlePlatformStarsLevelProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [startTime] = useState(Date.now());
  const [starsCollected, setStarsCollected] = useState(0);
  const totalStars = 5;
  const { playSfx } = useAudioManager();

  const gameStateRef = useRef({
    player: { x: 50, y: 300, width: 40, height: 40, velocityY: 0, isJumping: false },
    stars: [] as Array<{ x: number; y: number; collected: boolean }>,
    platforms: [
      { x: 0, y: 380, width: 800, height: 20 },
      { x: 150, y: 300, width: 120, height: 15 },
      { x: 350, y: 250, width: 120, height: 15 },
      { x: 550, y: 200, width: 120, height: 15 }
    ],
    keys: { left: false, right: false, up: false }
  });

  useEffect(() => {
    // Initialize stars
    gameStateRef.current.stars = [
      { x: 200, y: 260, collected: false },
      { x: 400, y: 210, collected: false },
      { x: 600, y: 160, collected: false },
      { x: 300, y: 150, collected: false },
      { x: 500, y: 100, collected: false }
    ];

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const state = gameStateRef.current;
      if (e.key === 'ArrowLeft') state.keys.left = true;
      if (e.key === 'ArrowRight') state.keys.right = true;
      if (e.key === 'ArrowUp' || e.key === ' ') {
        if (!state.player.isJumping) {
          state.keys.up = true;
          state.player.velocityY = -12;
          state.player.isJumping = true;
          playSfx('click');
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const state = gameStateRef.current;
      if (e.key === 'ArrowLeft') state.keys.left = false;
      if (e.key === 'ArrowRight') state.keys.right = false;
      if (e.key === 'ArrowUp' || e.key === ' ') state.keys.up = false;
    };

    const handleClick = () => {
      const state = gameStateRef.current;
      if (!state.player.isJumping) {
        state.player.velocityY = -12;
        state.player.isJumping = true;
        playSfx('click');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    canvas.addEventListener('click', handleClick);

    let animationId: number;

    const gameLoop = () => {
      const state = gameStateRef.current;
      const player = state.player;

      // Movement
      if (state.keys.left) player.x -= 5;
      if (state.keys.right) player.x += 5;

      // Gravity
      player.velocityY += 0.5;
      player.y += player.velocityY;

      // Platform collision
      let onPlatform = false;
      state.platforms.forEach(platform => {
        if (
          player.x + player.width > platform.x &&
          player.x < platform.x + platform.width &&
          player.y + player.height >= platform.y &&
          player.y + player.height <= platform.y + 20 &&
          player.velocityY >= 0
        ) {
          player.y = platform.y - player.height;
          player.velocityY = 0;
          player.isJumping = false;
          onPlatform = true;
        }
      });

      // Boundaries
      if (player.x < 0) player.x = 0;
      if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
      if (player.y > canvas.height) player.y = 300;

      // Star collection
      state.stars.forEach(star => {
        if (!star.collected) {
          const dist = Math.hypot(player.x + player.width / 2 - star.x, player.y + player.height / 2 - star.y);
          if (dist < 30) {
            star.collected = true;
            setStarsCollected(prev => {
              const newCount = prev + 1;
              if (onStarCollect) onStarCollect();
              playSfx('star');
              
              if (newCount >= totalStars) {
                const timeTaken = Math.floor((Date.now() - startTime) / 1000);
                const starsEarned = timeTaken < 30 ? 3 : timeTaken < 45 ? 2 : 1;
                setTimeout(() => {
                  onComplete({ starsEarned, timeTaken });
                }, 500);
              }
              return newCount;
            });
          }
        }
      });

      // Draw
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background gradient
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, 'oklch(0.85 0.1 220)');
      gradient.addColorStop(1, 'oklch(0.95 0.05 220)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Platforms
      ctx.fillStyle = 'oklch(0.7 0.15 220)';
      state.platforms.forEach(platform => {
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      });

      // Stars
      ctx.font = '30px Arial';
      state.stars.forEach(star => {
        if (!star.collected) {
          ctx.fillText('⭐', star.x - 15, star.y + 10);
        }
      });

      // Player
      ctx.fillStyle = 'oklch(0.65 0.2 250)';
      ctx.fillRect(player.x, player.y, player.width, player.height);
      ctx.fillText('😊', player.x + 5, player.y + 30);

      animationId = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      canvas.removeEventListener('click', handleClick);
      cancelAnimationFrame(animationId);
    };
  }, [onComplete, onStarCollect, playSfx, startTime]);

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card/90 backdrop-blur-sm p-6">
        <div className="text-center mb-4">
          <h2 className="text-2xl font-bold mb-2">Jump and Collect Stars!</h2>
          <p className="text-muted-foreground">Use arrow keys or click to jump ☁️</p>
          <p className="text-sm text-muted-foreground mt-2">
            Stars: {starsCollected} / {totalStars}
          </p>
        </div>
        <canvas
          ref={canvasRef}
          width={800}
          height={400}
          className="w-full border-4 border-primary/20 rounded-lg"
        />
      </Card>
    </div>
  );
}
