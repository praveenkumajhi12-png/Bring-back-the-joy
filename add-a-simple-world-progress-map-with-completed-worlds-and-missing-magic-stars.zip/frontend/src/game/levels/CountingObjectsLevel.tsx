import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAudioManager } from '../../audio/useAudioManager';

interface CountingObjectsLevelProps {
  onComplete: (result: { starsEarned: number; timeTaken: number; badges?: string[] }) => void;
  onStarCollect?: () => void;
}

const objects = ['🦋', '🐝', '🐞', '🦗', '🐛'];

export default function CountingObjectsLevel({ onComplete, onStarCollect }: CountingObjectsLevelProps) {
  const [currentRound, setCurrentRound] = useState(0);
  const [displayedObjects, setDisplayedObjects] = useState<string[]>([]);
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [score, setScore] = useState(0);
  const [startTime] = useState(Date.now());
  const [totalRounds] = useState(5);
  const { playSfx } = useAudioManager();

  useEffect(() => {
    generateRound();
  }, []);

  const generateRound = () => {
    const object = objects[Math.floor(Math.random() * objects.length)];
    const count = Math.floor(Math.random() * 8) + 3; // 3-10 objects
    const objectArray = Array(count).fill(object);
    setDisplayedObjects(objectArray);
    setCorrectAnswer(count);
  };

  const handleAnswer = (answer: number) => {
    if (answer === correctAnswer) {
      playSfx('correct');
      setScore(prev => prev + 1);
      if (onStarCollect) onStarCollect();
    } else {
      playSfx('incorrect');
    }

    if (currentRound + 1 >= totalRounds) {
      // Level complete
      const timeTaken = Math.floor((Date.now() - startTime) / 1000);
      const starsEarned = score >= 4 ? 3 : score >= 3 ? 2 : 1;
      const isPerfect = score === totalRounds;
      setTimeout(() => {
        onComplete({ 
          starsEarned, 
          timeTaken, 
          badges: isPerfect ? ['math-star'] : [] 
        });
      }, 500);
    } else {
      setCurrentRound(prev => prev + 1);
      setTimeout(generateRound, 500);
    }
  };

  const answerOptions = [
    correctAnswer - 1,
    correctAnswer,
    correctAnswer + 1,
    correctAnswer + 2
  ].filter(n => n > 0).sort(() => Math.random() - 0.5).slice(0, 4);

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card/90 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">Count the Objects!</h2>
            <p className="text-muted-foreground">How many do you see? 🔢</p>
            <p className="text-sm text-muted-foreground mt-2">
              Round {currentRound + 1} of {totalRounds} • Score: {score}
            </p>
          </div>

          <div className="bg-muted/30 rounded-lg p-8 mb-6 min-h-[200px] flex flex-wrap gap-3 justify-center items-center">
            {displayedObjects.map((obj, index) => (
              <span key={index} className="text-5xl animate-float" style={{ animationDelay: `${index * 0.1}s` }}>
                {obj}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {answerOptions.map((option) => (
              <Button
                key={option}
                onClick={() => handleAnswer(option)}
                size="lg"
                className="h-20 text-3xl font-bold game-button bg-primary hover:bg-primary/90"
              >
                {option}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
