import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAudioManager } from '../../audio/useAudioManager';

interface MemoryFlipCardsLevelProps {
  onComplete: (result: { starsEarned: number; timeTaken: number; badges?: string[] }) => void;
  onStarCollect?: () => void;
}

const cardItems = ['⭐', '🌟', '✨', '💫', '🌠', '🎆', '🎇', '🎉'];

export default function MemoryFlipCardsLevel({ onComplete, onStarCollect }: MemoryFlipCardsLevelProps) {
  const [cards, setCards] = useState<string[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [startTime] = useState(Date.now());
  const [moves, setMoves] = useState(0);
  const { playSfx } = useAudioManager();

  useEffect(() => {
    const selectedCards = cardItems.slice(0, 6);
    const cardPairs = [...selectedCards, ...selectedCards];
    const shuffled = cardPairs.sort(() => Math.random() - 0.5);
    setCards(shuffled);
  }, []);

  const handleFlip = (index: number) => {
    if (flipped.length >= 2 || matched.includes(index) || flipped.includes(index)) return;

    const newFlipped = [...flipped, index];
    setFlipped(newFlipped);
    playSfx('click');

    if (newFlipped.length === 2) {
      setMoves(prev => prev + 1);
      const [first, second] = newFlipped;

      if (cards[first] === cards[second]) {
        playSfx('correct');
        const newMatched = [...matched, first, second];
        setMatched(newMatched);
        setFlipped([]);
        
        if (onStarCollect) onStarCollect();

        if (newMatched.length === cards.length) {
          const timeTaken = Math.floor((Date.now() - startTime) / 1000);
          const starsEarned = moves <= 10 ? 3 : moves <= 15 ? 2 : 1;
          const isPerfect = moves <= 10;
          setTimeout(() => {
            onComplete({ 
              starsEarned, 
              timeTaken, 
              badges: isPerfect ? ['memory-master'] : [] 
            });
          }, 500);
        }
      } else {
        playSfx('incorrect');
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card/90 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">Memory Match!</h2>
            <p className="text-muted-foreground">Find all the matching pairs 🧠</p>
            <p className="text-sm text-muted-foreground mt-2">Moves: {moves}</p>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
            {cards.map((card, index) => {
              const isFlipped = flipped.includes(index);
              const isMatched = matched.includes(index);
              const isVisible = isFlipped || isMatched;

              return (
                <Button
                  key={index}
                  onClick={() => handleFlip(index)}
                  disabled={isMatched}
                  className={`h-24 text-5xl transition-all ${
                    isMatched ? 'bg-success/20 cursor-default' :
                    isFlipped ? 'bg-primary/20' :
                    'bg-gradient-to-br from-primary/60 to-accent/60 hover:from-primary/70 hover:to-accent/70'
                  }`}
                >
                  {isVisible ? card : '?'}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
