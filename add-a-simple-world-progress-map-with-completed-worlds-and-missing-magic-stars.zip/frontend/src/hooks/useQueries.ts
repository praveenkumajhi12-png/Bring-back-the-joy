import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { PlayerProgress, UserProfile } from '../backend';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useGetMyProgress() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<PlayerProgress>({
    queryKey: ['myProgress'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getMyProgress();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useUpdateLevel() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ levelNumber, starsEarned, timeTaken }: { levelNumber: number; starsEarned: number; timeTaken: number }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateLevel(BigInt(levelNumber), BigInt(starsEarned), BigInt(timeTaken));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myProgress'] });
    },
  });
}

export function useAddBadge() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (badge: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addBadge(badge);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myProgress'] });
      queryClient.invalidateQueries({ queryKey: ['myBadges'] });
    },
  });
}

export function useGetMyBadges() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<string[]>({
    queryKey: ['myBadges'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getMyBadges();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useResetMyProgress() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.resetMyProgress();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myProgress'] });
      queryClient.invalidateQueries({ queryKey: ['myBadges'] });
    },
  });
}
