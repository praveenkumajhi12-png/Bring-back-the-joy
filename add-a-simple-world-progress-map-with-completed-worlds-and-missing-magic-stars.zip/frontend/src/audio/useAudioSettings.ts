import { useState, useEffect } from 'react';

export interface AudioSettings {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  musicVolume: number;
  sfxVolume: number;
}

const STORAGE_KEY = 'magicStars_audioSettings';

const defaultSettings: AudioSettings = {
  musicEnabled: true,
  sfxEnabled: true,
  musicVolume: 0.5,
  sfxVolume: 0.7
};

export function useAudioSettings() {
  const [settings, setSettings] = useState<AudioSettings>(defaultSettings);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Failed to load audio settings:', error);
    }
  }, []);

  const updateSettings = (partial: Partial<AudioSettings>) => {
    const updated = { ...settings, ...partial };
    setSettings(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Failed to save audio settings:', error);
    }
  };

  return { settings, updateSettings };
}
