import { useEffect, useRef, useCallback } from 'react';
import { useAudioSettings } from './useAudioSettings';

type SfxType = 'click' | 'correct' | 'incorrect' | 'star' | 'complete' | 'gameplay';

export function useAudioManager() {
  const { settings } = useAudioSettings();
  const menuMusicRef = useRef<HTMLAudioElement | null>(null);
  const gameplayMusicRef = useRef<HTMLAudioElement | null>(null);
  const sfxRefs = useRef<Map<SfxType, HTMLAudioElement>>(new Map());
  const isInitialized = useRef(false);

  const initAudio = useCallback(() => {
    if (isInitialized.current) return;
    isInitialized.current = true;

    // Initialize music
    menuMusicRef.current = new Audio('/assets/audio/music-menu.mp3');
    menuMusicRef.current.loop = true;
    
    gameplayMusicRef.current = new Audio('/assets/audio/music-gameplay.mp3');
    gameplayMusicRef.current.loop = true;

    // Initialize SFX
    const sfxFiles: Record<SfxType, string> = {
      click: '/assets/audio/sfx-click.wav',
      correct: '/assets/audio/sfx-correct.wav',
      incorrect: '/assets/audio/sfx-incorrect.wav',
      star: '/assets/audio/sfx-star.wav',
      complete: '/assets/audio/sfx-complete.wav',
      gameplay: '/assets/audio/sfx-click.wav' // Reuse click for now
    };

    Object.entries(sfxFiles).forEach(([type, src]) => {
      const audio = new Audio(src);
      sfxRefs.current.set(type as SfxType, audio);
    });
  }, []);

  // Update volumes when settings change
  useEffect(() => {
    if (menuMusicRef.current) {
      menuMusicRef.current.volume = settings.musicVolume * 0.5; // Lower default volume
    }
    if (gameplayMusicRef.current) {
      gameplayMusicRef.current.volume = settings.musicVolume * 0.5;
    }
  }, [settings.musicVolume]);

  // Play/pause music based on settings
  useEffect(() => {
    if (!isInitialized.current) return;

    if (settings.musicEnabled && menuMusicRef.current) {
      menuMusicRef.current.play().catch(() => {
        // Autoplay blocked, will play on user interaction
      });
    } else if (menuMusicRef.current) {
      menuMusicRef.current.pause();
    }
  }, [settings.musicEnabled]);

  const playSfx = useCallback((type: SfxType) => {
    if (!settings.sfxEnabled) return;
    
    const sfx = sfxRefs.current.get(type);
    if (sfx) {
      sfx.volume = settings.sfxVolume * 0.6; // Lower default volume
      sfx.currentTime = 0;
      sfx.play().catch(() => {
        // Ignore autoplay errors
      });
    }
  }, [settings.sfxEnabled, settings.sfxVolume]);

  return {
    initAudio,
    playSfx
  };
}
