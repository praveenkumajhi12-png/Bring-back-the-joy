# Specification

## Summary
**Goal:** Add a kid-friendly “Progress Map” screen that shows each world’s completion status and how many magic stars are still missing, using existing progress data.

**Planned changes:**
- Add a new “Progress Map” view reachable from the World Select experience, preserving the user’s current progress state.
- Display per-world completion (complete when all levels in the world are completed) and the missing magic stars count (missing = levelsInWorld * 3 − earnedStarsForWorld) based on existing `progress: LocalProgress | null` flow for both guests and logged-in users.
- Build a responsive (mobile + desktop) Progress Map UI consistent with the current kid-friendly style and using the existing magic stars asset as an icon/decoration near star counts.

**User-visible outcome:** From World Select, users can open a Progress Map that clearly shows which worlds are complete and how many magic stars are still needed in each world, on both mobile and desktop.
